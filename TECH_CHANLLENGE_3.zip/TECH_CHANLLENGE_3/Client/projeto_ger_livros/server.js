const express = require('express');
const sequelize = require('./config/database');
const livroRoutes = require('./routes/livroRoutes');
const path = require('path');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Configura o diretório de arquivos estáticos (onde React será servido)
app.use(express.static(path.join(__dirname, 'public')));

// Rotas da API
app.use('/api', livroRoutes);

// Serve o arquivo index.html diretamente para a rota raiz
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});



// Conectar ao banco de dados e iniciar o servidor
sequelize.sync()
  .then(() => {
    console.log('Conectado ao banco de dados');
    app.listen(PORT, () => {
      console.log(`Servidor rodando em http://localhost:${PORT}`);
    });
  })
  .catch((error) => console.log('Erro ao conectar ao banco de dados:', error));
