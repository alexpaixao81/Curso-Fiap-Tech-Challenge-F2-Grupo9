import './estilo.css'; // Importing your local CSS
import Home from './components/Home';
import Livros from './components/Livros';

import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import { Nav } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (
    <div className="App"> {/* Corrected "class" to "className" */}
      <a className="navbar-brand" href="/"> {/* Corrected "class" to "className" and "href" for the home */}
        <img src="./img/logo.png" alt="Company Logo" width="70" height="70" className="d-inline-block align-center" />
        <title>Gerenciamento de Livros</title> {/* Corrected "tittle" to "title" */}  
      </a>    
      
      <BrowserRouter>

        <Nav variant="tabs">
          <Nav.Link as={Link} to="/">Inicio</Nav.Link> {/* Link to Home */}
          <Nav.Link as={Link} to="/livros">Cadastro de Livros</Nav.Link> {/* Link to Book Registration */}
        </Nav>

        <Routes> {/* Defining the routes correctly */}
          <Route path="/" element={<Home />} /> {/* Route for Home */}
          <Route path="/livros" element={<Livros />} /> {/* Route for Books */}
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;


