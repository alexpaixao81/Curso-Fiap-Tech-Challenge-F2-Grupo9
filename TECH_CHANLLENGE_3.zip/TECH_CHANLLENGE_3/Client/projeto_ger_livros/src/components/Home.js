import React from 'react';
import { Helmet } from 'react-helmet';

function Home() {
    return (
        <>
            <Helmet>
                <meta charSet="UTF-8" />
                <meta name="viewport" content="width=device-width, initial-scale=1.0" />
                <meta http-equiv="X-UA-Compatible" content="ie=edge" />
                <title>Gerenciamento de Livros</title>
                {/* Bootstrap CSS */}
                <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
                {/* Custom CSS */}
                <link rel="stylesheet" href="src/estilo.css" />
            </Helmet>

            <div>

                {/* Main Section (Página 1) */}
                <section className="container-fluid home-section d-flex align-items-center justify-content-center text-center" id="home">
                    <div className="row">
                        <div className="col-md-6 text-center text-md-start">
                            <h1>Gerencie sua Biblioteca com Facilidade!</h1>
                            <p className="lead">
                                Nossa plataforma ajuda você a cadastrar, organizar e gerenciar sua coleção de livros e autores. Simplifique sua gestão e mantenha sua biblioteca em dia!
                            </p>
                            <p className="slogan">
                                "Sua biblioteca, sempre à mão!"
                            </p>
                            {/* Botões: "Começar Agora" e "Saiba Mais" */}
                            <a href="#benefits" className="btn btn-outline-light btn-lg mt-3">Saiba Mais</a>
                            <a href="#planos" className="btn btn-primary btn-lg mt-3 me-2">Começar Agora</a>
                        </div>
                        <div className="col-md-6 d-none d-md-block">
                            <img src="./img/Pessoalendo.jpeg" alt="Gerenciamento de Livros" width="400" height="300" className="img-fluid rounded-image" />
                        </div>
                    </div>
                </section>

                {/* Benefits Section (Página 2) */}
                <section className="container-fluid benefits-section text-center py-5" id="benefits">
                    <h2>Por que usar nossa plataforma?</h2>
                    <div className="row mt-5">
                        <div className="col-md-4">
                            <h3>Organização Eficiente</h3>
                            <p>Tenha total controle sobre sua biblioteca com recursos de categorização e organização que facilitam o gerenciamento de livros e autores.</p>
                        </div>
                        <div className="col-md-4">
                            <h3>Acessível de Qualquer Lugar</h3>
                            <p>Acesse e gerencie sua biblioteca de qualquer dispositivo, a qualquer momento. Tenha todas as suas informações na palma da mão!</p>
                        </div>
                        <div className="col-md-4">
                            <h3>Suporte e Atualizações</h3>
                            <p>Com suporte técnico dedicado e atualizações frequentes, garantimos que você terá a melhor experiência possível na gestão de sua biblioteca.</p>
                        </div>
                    </div>
                </section>

                {/* Plans Section (Página 3) */}
                <section className="container-fluid plans-section text-center py-5" id="planos">
                    <h2>Nossos Planos</h2>
                    <p className="lead">Escolha o plano que mais se adapta às suas necessidades</p>
                    <div className="table-responsive mt-4">
                        <table className="table table-bordered table-striped">
                            <thead className="table-dark">
                                <tr>
                                    <th>Plano</th>
                                    <th>Recursos</th>
                                    <th>Preço</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><strong>Plano Básico</strong></td>
                                    <td>Acesso à plataforma, cadastro de até 100 livros, suporte via email.</td>
                                    <td>R$ 29,90 / mês</td>
                                </tr>
                                <tr>
                                    <td><strong>Plano Profissional</strong></td>
                                    <td>Cadastro de até 1000 livros, suporte 24/7, relatórios avançados de gestão.</td>
                                    <td>R$ 99,90 / mês</td>
                                </tr>
                                <tr>
                                    <td><strong>Plano Premium</strong></td>
                                    <td>Acesso ilimitado, integração com dispositivos móveis, suporte prioritário.</td>
                                    <td>R$ 199,90 / mês</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </section>

                {/* Contact Form Section (Página 4) */}
                <section className="container-fluid contact-section text-center py-5" id="contato">
                    <h2>Entre em Contato</h2>
                    <p className="lead">Fale conosco para saber mais ou se tiver alguma dúvida!</p>
                    <form className="row g-3">
                        <div className="col-md-6">
                            <input type="text" className="form-control" id="nome" placeholder="Nome completo" required />
                        </div>
                        <div className="col-md-6">
                            <input type="email" className="form-control" id="email" placeholder="Email" required />
                        </div>
                        <div className="col-12">
                            <textarea className="form-control" id="mensagem" rows="4" placeholder="Sua mensagem" required></textarea>
                        </div>
                        <div className="col-12">
                            <button type="submit" className="btn btn-primary">Enviar</button>
                        </div>
                    </form>
                </section>

                {/* Footer */}
                <footer className="text-center py-3">
                    <p>&copy; 2024 Grupo 9 - Todos os direitos reservados</p>
                </footer>
            </div>
        </>
    );
}

export default Home;
