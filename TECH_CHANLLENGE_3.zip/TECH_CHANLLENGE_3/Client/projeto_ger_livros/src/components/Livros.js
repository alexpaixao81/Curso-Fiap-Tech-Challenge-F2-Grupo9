import React from "react";
import { Table, Button, Form, Modal } from 'react-bootstrap';

class Livros extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            livro_id: '0',
            nome: '',
            autor: '',
            editora: '',
            livros: [],
            modalAberta: false
        };
    }

    componentDidMount() {
        this.buscarLivro();
    }

    buscarLivro = () => {
        fetch("http://localhost:5001/api/livros")
            .then(resposta => resposta.json())
            .then(dados => {
                this.setState({ livros: dados });
            })

    }

    deletarLivro = (livro_id) => {
        fetch(`http://localhost:5001/api/livros/${livro_id}`, { method: 'DELETE' })
            .then(resposta => {
                if (resposta.ok) {
                    this.buscarLivro();

                }
            })

    }

    carregarDados = (livro_id) => {
        fetch(`http://localhost:5001/api/livros/${livro_id}`, { method: 'GET' })
            .then(resposta => resposta.json())
            .then(livro => {
                this.setState({
                    livro_id: livro.livro_id,
                    nome: livro.nome,
                    autor: livro.autor,
                    editora: livro.editora


                });
                this.abrirModal();
            })

    }

    atualizarDados = (livro) => {
        fetch(`http://localhost:5001/api/livros/${livro.livro_id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(livro)
        })
            .then(resposta => {
                if (resposta.ok) {
                    this.buscarLivro();
                } else {
                    alert('Não foi possivel atualizar o Livro');
                }
            })

    }

    cadastraLivro = (livro) => {
        fetch(`http://localhost:5001/api/livros/`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(livro)
        })
            .then(resposta => {
                if (resposta.ok) {
                    this.buscarLivro();
                } else {
                    alert('Não foi possivel adicionar o Livro');
                }
            })

    }
    renderTabela = () => {
        return (
            <Table striped bordered hover>
                <thead>
                    <tr>
                        <th>Nome</th>
                        <th>Autor</th>
                        <th>Editora</th>
                        <th>Ação</th>
                    </tr>
                </thead>
                <tbody>
                    {this.state.livros.map((livro) => (
                        <tr key={livro.livro_id}>
                            <td>{livro.nome}</td>
                            <td>{livro.autor}</td>
                            <td>{livro.editora}</td>
                            <td>
                                <Button variant="secondary" onClick={() => this.carregarDados(livro.livro_id)}>Atualizar</Button>
                                <Button variant="danger" onClick={() => this.deletarLivro(livro.livro_id)}>Deletar</Button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </Table>
        );
    }

    atualizaNome = (e) => {
        this.setState(
            {
                nome: e.target.value
            }
        )
    }

    atualizaAutor = (e) => {
        this.setState(
            {
                autor: e.target.value
            }
        )
    }

    atualizaEditora = (e) => {
        this.setState(
            {
                editora: e.target.value
            }
        )
    }

    submit = () => {

        if (this.state.livro_id === 0) {
            const livro = {
                nome: this.state.nome,
                autor: this.state.autor,
                editora: this.state.editora
            }
            this.cadastraLivro(livro);
        } else {
            const livro = {
                livro_id: this.state.livro_id,
                nome: this.state.nome,
                autor: this.state.autor,
                editora: this.state.editora
            }
            this.atualizarDados(livro);
        }

        this.fecharModal();
    }


    reset = () => {


        this.setState(
            {
                livro_id: 0,
                nome: '',
                autor: '',
                editora: ''

            }
        )
        this.abrirModal();
    }


    fecharModal = () => {
        this.setState(
            {
                modalAberta: false
            }


        )

    }
    abrirModal = () => {
        this.setState(
            {
                modalAberta: true
            }


        )

    }



    render() {
        return (
            <div>

                <Modal show={this.state.modalAberta} onHide={this.fecharModal}>
                    <Modal.Header closeButton>
                        <Modal.Title>Dados do Livro</Modal.Title>
                    </Modal.Header>

                    <Modal.Body>

                        <Form>
                            <Form.Group className="mb-3">
                                <Form.Label>ID</Form.Label>
                                <Form.Control type="text" value={this.state.livro_id} readOnly={true} />
                            </Form.Group>
                            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                <Form.Label>Nome</Form.Label>
                                <Form.Control type="text" placeholder="Digite o Nome do livro" value={this.state.nome} onChange={this.atualizaNome} />
                            </Form.Group>
                            <Form.Group className="mb-3" controlId="exampleForm.ControlInput2">
                                <Form.Label>Autor</Form.Label>
                                <Form.Control type="text" placeholder="Digite o Nome do Autor" value={this.state.autor} onChange={this.atualizaAutor} />
                            </Form.Group>
                            <Form.Group className="mb-3" controlId="exampleForm.ControlInput3">
                                <Form.Label>Editora</Form.Label>
                                <Form.Control type="text" placeholder="Digite o Nome da Editora" value={this.state.editora} onChange={this.atualizaEditora} />
                            </Form.Group>


                        </Form>


                    </Modal.Body>

                    <Modal.Footer>
                        <Button variant="secondary" onClick={this.fecharModal}>
                            Fechar
                        </Button>
                        <Button variant="primary" type="submit" onClick={this.submit}>
                            Salvar
                        </Button>
                    </Modal.Footer>
                </Modal>

                <Button variant="warning" onClick={this.reset}>
                    Novo
                </Button>


                {this.renderTabela()}
            </div>
        );
    }
}

export default Livros;
